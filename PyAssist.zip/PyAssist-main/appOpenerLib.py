from AppOpener import *
import time

open("calendar",match_closest=True)
time.sleep(5)
close('calendar',match_closest=True)