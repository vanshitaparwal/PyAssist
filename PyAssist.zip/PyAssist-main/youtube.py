import pywhatkit

pywhatkit.playonyt("ram siya ramṇ")

print("Played")